//
//  AppDelegate.h
//  LocoMotive
//
//  Created by Tolga Caner on 28/04/2017.
//  Copyright © 2017 Tolga Caner. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

