//
//  ViewController.m
//  LocoMotive
//
//  Created by Tolga Caner on 28/04/2017.
//  Copyright © 2017 Tolga Caner. All rights reserved.
//

#import "ViewController.h"
#import "NSDictionary+BVJSONString.h"

@interface ViewController () <SRWebSocketDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://localhost:8887"]];
    self.webRocket = [[SRWebSocket alloc] initWithURLRequest:urlRequest];
    self.webRocket.delegate = self;
    [self.webRocket open];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)btnAction:(id)sender {
    NSLog(@"btn action");
    //NSString* text = @"testmessage";
    NSDictionary* dict = @{@"id": @1, @"name" : @"player1", @"message" : @"hello world"};
    //NSData* data = [NSKeyedArchiver archivedDataWithRootObject:dict];
    NSString* jsonString = [dict bv_jsonStringWithPrettyPrint:NO];
    [self.webRocket send:jsonString];
}


- (void)webSocket:(SRWebSocket *)webSocket didReceiveMessage:(id)message {
    NSLog(@"didReceiveMessage");
    
}

- (void)webSocketDidOpen:(SRWebSocket *)webSocket {
    NSLog(@"webSocketDidOpen");
}

- (void)webSocket:(SRWebSocket *)webSocket didFailWithError:(NSError *)error {
    NSLog(@"didFailWithError");
}

- (void)webSocket:(SRWebSocket *)webSocket didCloseWithCode:(NSInteger)code reason:(NSString *)reason wasClean:(BOOL)wasClean {
    NSLog(@"didCloseWithCode");
}
- (void)webSocket:(SRWebSocket *)webSocket didReceivePong:(NSData *)pongPayload {
    NSLog(@"didReceivePong");
}
// Return YES to convert messages sent as Text to an NSString. Return NO to skip NSData -> NSString conversion for Text messages. Defaults to YES.
- (BOOL)webSocketShouldConvertTextFrameToString:(SRWebSocket *)webSocket {
    return YES;
}


@end
